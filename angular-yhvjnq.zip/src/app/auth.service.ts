import { Injectable } from '@angular/core';

@Injectable()
export class AuthService {

  constructor() { }

  getUserDetails()
  {
    //post these details to Api server and return user info if correct

    


  }

}